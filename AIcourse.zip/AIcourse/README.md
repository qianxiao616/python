# AIcourse - 课程排课难度预测系统

基于机器学习的ITC2007课程排课问题难度预测系统。

## 项目简介

本项目使用机器学习方法预测课程排课问题的难度。通过从ITC2007数据集中提取特征，并使用贪心求解器生成难度标签，训练多种回归模型来预测新实例的排课难度。

## 项目结构

```
AIcourse/
├── src/                    # 源代码
│   ├── feature_extractor.py   # 特征提取模块
│   ├── label_generator.py     # 标签生成模块
│   ├── model_trainer.py       # 模型训练模块
│   └── visualizer.py          # 可视化模块
├── data/                   # 数据文件
│   ├── features.csv           # 提取的特征数据
│   └── raw/                   # 原始.ctt文件链接
├── results/                # 结果输出
│   ├── model_comparison.csv   # 模型对比结果
│   └── figures/               # 可视化图表
├── models/                 # 保存的模型
├── main.py                 # 主程序
├── requirements.txt        # 依赖包
└── README.md              # 本文件
```

## 特征说明

本项目提取以下类别的特征：

### 1. 规模类特征 (5个)
- n_courses: 课程数量
- total_lectures: 讲座总次数
- n_rooms: 教室数量
- n_curricula: 课程组数量
- n_unavailability_constraints: 不可用约束总数

### 2. 约束紧密度特征 (6个)
- avg_curriculum_size: 平均课程组大小
- max_curriculum_size: 最大课程组大小
- constraint_density: 课程组冲突密度
- teacher_conflict_density: 教师冲突密度
- avg_unavailable_per_course: 平均每门课不可用时段数
- courses_in_curricula_ratio: 被课程组覆盖的课程比例

### 3. 资源匹配特征 (6个)
- room_capacity_mean: 教室平均容量
- room_capacity_std: 教室容量标准差
- student_count_mean: 课程平均学生数
- student_count_std: 学生数标准差
- avg_students_per_room_capacity: 学生与教室容量比
- room_utilization_pressure: 时段利用压力

### 4. 时间分布特征 (3个)
- avg_min_working_days: 课程平均最少工作天数
- lectures_per_timeslot_ratio: 讲座与时段比
- time_slack: 时间松弛度

**总计：20个特征**

## 模型对比

本项目训练并对比以下模型：

1. **线性回归** (Baseline)
2. **随机森林回归** (RandomForest)
3. **梯度提升回归** (GradientBoosting)
4. **支持向量回归** (SVR)
5. **XGBoost回归** (如果可用)

## 评估方法

- **交叉验证**: 留一法 (LOOCV) - 适合小样本
- **评估指标**: 
  - RMSE (均方根误差)
  - MAE (平均绝对误差)
  - R² (决定系数)

## 使用方法

### 1. 安装依赖
```bash
cd ~/Desktop/AIcourse
pip install -r requirements.txt
```

### 2. 生成数据集
```bash
python main.py --generate-data
```

### 3. 训练模型
```bash
python main.py --train
```

### 4. 完整流程
```bash
python main.py --all
```

## 结果

运行后会在 `results/` 目录生成：
- 模型性能对比表
- 预测vs实际散点图
- 特征重要性图
- 交叉验证结果图

## 依赖项

- Python 3.7+
- pandas
- numpy
- scikit-learn
- matplotlib
- seaborn
- xgboost (可选)

## 作者

课程作业项目 - 2026

## 参考

- ITC2007 Curriculum-Based Course Timetabling
- pycourse 求解器项目
